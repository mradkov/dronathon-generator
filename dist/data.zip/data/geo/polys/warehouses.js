//warehouses
module.exports = [
    ["NETWORKING: Premium Coworking Space [Dronathon] {\"id\":0, \"location\": [42.7058171,23.3287061]}",42.7058171,23.3287061],
    ["Business Center Serdika {\"id\":1, \"location\": [42.691163,23.294588]}",42.691163,23.294588],
    ["Bulgaria Mall {\"id\":2, \"location\": [42.6643476,23.289005]}",42.6643476,23.289005],
    ["Airport Sofia [Terminal 1] {\"id\":3, \"location\": [42.6895872,23.4027335000001]}",42.6895872,23.4027335000001],
    ["SoftUni {\"id\":4, \"location\": [42.6666605,23.3506835000001]}",42.6666605,23.3506835000001],
    ["NBU {\"id\":5, \"location\": [42.67786, 23.25269]}",42.67786, 23.25269],
    ["Lyulin, Sofia {\"id\":6, \"location\": [42.723894,23.2375028]}",42.723894,23.2375028],
];